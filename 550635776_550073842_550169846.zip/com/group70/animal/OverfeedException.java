package com.group70.animal;

public class OverfeedException extends Exception {
    public OverfeedException(String message) {
        super(message);
    }
}
