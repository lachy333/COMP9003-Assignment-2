package com.group70.animal;

public class InvalidPortionException extends Exception {
    public InvalidPortionException(String message) {
        super(message);
    }
}