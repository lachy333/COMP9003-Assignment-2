package com.group70.keeper;

public class ExpertiseMismatchException extends Exception {
    public ExpertiseMismatchException(String message) {
        super(message);
    }
}
